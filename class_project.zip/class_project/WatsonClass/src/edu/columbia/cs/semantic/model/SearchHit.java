

/* First created by JCasGen Wed Mar 06 00:08:02 EST 2013 */
package edu.columbia.cs.semantic.model;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import org.apache.uima.jcas.cas.TOP;


/** This object represents a single document/passage search result (hit) from a document search.
 * Updated by JCasGen Wed Mar 06 00:08:02 EST 2013
 * XML source: /home/sid/Workspaces/ColumbiaProject/edu.columbia.cs.semantic.model/descriptors/edu/columbia/cs/semantic/model/types.xml
 * @generated */
public class SearchHit extends TOP {
  /** @generated
   * @ordered 
   */
  @SuppressWarnings ("hiding")
  public final static int typeIndexID = JCasRegistry.register(SearchHit.class);
  /** @generated
   * @ordered 
   */
  @SuppressWarnings ("hiding")
  public final static int type = typeIndexID;
  /** @generated  */
  @Override
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected SearchHit() {/* intentionally empty block */}
    
  /** Internal - constructor used by generator 
   * @generated */
  public SearchHit(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public SearchHit(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {/*default - does nothing empty block */}
     
 
    
  //*--------------*
  //* Feature: text

  /** getter for text - gets This feature contains the text of the document/passage retrieved during search
   * @generated */
  public String getText() {
    if (SearchHit_Type.featOkTst && ((SearchHit_Type)jcasType).casFeat_text == null)
      jcasType.jcas.throwFeatMissing("text", "edu.columbia.cs.semantic.model.SearchHit");
    return jcasType.ll_cas.ll_getStringValue(addr, ((SearchHit_Type)jcasType).casFeatCode_text);}
    
  /** setter for text - sets This feature contains the text of the document/passage retrieved during search 
   * @generated */
  public void setText(String v) {
    if (SearchHit_Type.featOkTst && ((SearchHit_Type)jcasType).casFeat_text == null)
      jcasType.jcas.throwFeatMissing("text", "edu.columbia.cs.semantic.model.SearchHit");
    jcasType.ll_cas.ll_setStringValue(addr, ((SearchHit_Type)jcasType).casFeatCode_text, v);}    
   
    
  //*--------------*
  //* Feature: rank

  /** getter for rank - gets This feature contains the rank of the document in during the document search
   * @generated */
  public int getRank() {
    if (SearchHit_Type.featOkTst && ((SearchHit_Type)jcasType).casFeat_rank == null)
      jcasType.jcas.throwFeatMissing("rank", "edu.columbia.cs.semantic.model.SearchHit");
    return jcasType.ll_cas.ll_getIntValue(addr, ((SearchHit_Type)jcasType).casFeatCode_rank);}
    
  /** setter for rank - sets This feature contains the rank of the document in during the document search 
   * @generated */
  public void setRank(int v) {
    if (SearchHit_Type.featOkTst && ((SearchHit_Type)jcasType).casFeat_rank == null)
      jcasType.jcas.throwFeatMissing("rank", "edu.columbia.cs.semantic.model.SearchHit");
    jcasType.ll_cas.ll_setIntValue(addr, ((SearchHit_Type)jcasType).casFeatCode_rank, v);}    
   
    
  //*--------------*
  //* Feature: score

  /** getter for score - gets This feature contains a search confidence score assigned by the retrieval engine
   * @generated */
  public double getScore() {
    if (SearchHit_Type.featOkTst && ((SearchHit_Type)jcasType).casFeat_score == null)
      jcasType.jcas.throwFeatMissing("score", "edu.columbia.cs.semantic.model.SearchHit");
    return jcasType.ll_cas.ll_getDoubleValue(addr, ((SearchHit_Type)jcasType).casFeatCode_score);}
    
  /** setter for score - sets This feature contains a search confidence score assigned by the retrieval engine 
   * @generated */
  public void setScore(double v) {
    if (SearchHit_Type.featOkTst && ((SearchHit_Type)jcasType).casFeat_score == null)
      jcasType.jcas.throwFeatMissing("score", "edu.columbia.cs.semantic.model.SearchHit");
    jcasType.ll_cas.ll_setDoubleValue(addr, ((SearchHit_Type)jcasType).casFeatCode_score, v);}    
   
    
  //*--------------*
  //* Feature: componentId

  /** getter for componentId - gets Component ID of the component that posted this feature structure
   * @generated */
  public String getComponentId() {
    if (SearchHit_Type.featOkTst && ((SearchHit_Type)jcasType).casFeat_componentId == null)
      jcasType.jcas.throwFeatMissing("componentId", "edu.columbia.cs.semantic.model.SearchHit");
    return jcasType.ll_cas.ll_getStringValue(addr, ((SearchHit_Type)jcasType).casFeatCode_componentId);}
    
  /** setter for componentId - sets Component ID of the component that posted this feature structure 
   * @generated */
  public void setComponentId(String v) {
    if (SearchHit_Type.featOkTst && ((SearchHit_Type)jcasType).casFeat_componentId == null)
      jcasType.jcas.throwFeatMissing("componentId", "edu.columbia.cs.semantic.model.SearchHit");
    jcasType.ll_cas.ll_setStringValue(addr, ((SearchHit_Type)jcasType).casFeatCode_componentId, v);}    
  }

    