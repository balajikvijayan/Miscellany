package edu.columbia.cs.semantic.sample.structured_data_search;

import java.io.File;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;

import edu.columbia.cs.semantic.env.Env;
import edu.columbia.cs.semantic.model.StructuredLookupResult;
import edu.columbia.cs.semantic.utilities.UimaTools;

/**
 * This is the Lucene-based structured data lookup AE. It expects a CAS with a QUERY view, and uses the
 * contents of the QUERY view to perform a search over some structured resource. The output from
 * this AE is a bunch of StructuredLookupResult objects added to the QUERY view of the CAS.
 * 
 * @author Or Biran
 */
public class LuceneStructuredDataLookup extends JCasAnnotator_ImplBase {

	private static final String COMPONENT_ID = "LuceneStructuredDataLookup";

	/**
	 * Any initializations of data structures/engines (e.g., a retrieval engine) would go into the
	 * initialize method. In this dummy class, we don't actually use a retrieval engine.
	 */
	@Override
	public void initialize(UimaContext aContext) throws ResourceInitializationException {
		super.initialize(aContext);
	}

	/**
	 * The process method receives one "query" CAS at a time, and performs a search for each.
	 */
	@Override
	public void process(JCas cas) throws AnalysisEngineProcessException {
		JCas queryView;
		try {
			queryView = cas.getView("QUERY");
			if (queryView == null) throw new Exception("Expecting QUERY view in CAS for primary document search");
			if (UimaTools.casContainsView(cas, "EXPANDED")) throw new Exception("Flow problem: found EXPANDED view in CAS; primary search CASes must not have EXPANDED view");
		} catch (Exception e) {
			throw new AnalysisEngineProcessException(e);
		}

		try {
			// prepare the lucene index and analyzer
			String indexDir = Env.getIndexDir();
			Directory index = FSDirectory.open(new File(indexDir));
			StandardAnalyzer analyzer = new StandardAnalyzer(Version.LUCENE_41);

			// the query comes from the queryView 
			Query query = new QueryParser(Version.LUCENE_41, "text", analyzer).parse(queryView.getDocumentText());

			// get the top 10 hits
			IndexReader reader = DirectoryReader.open(index);
			IndexSearcher searcher = new IndexSearcher(reader);
			TopScoreDocCollector collector = TopScoreDocCollector.create(/*numHits*/ 10, /*ordered*/ true);
			searcher.search(query, collector);
			ScoreDoc[] scoreDocs = collector.topDocs().scoreDocs;

			for (ScoreDoc scoreDoc : scoreDocs) {
				StructuredLookupResult hit0 = new StructuredLookupResult(queryView);
				hit0.setScore(scoreDoc.score);
				hit0.setComponentId(COMPONENT_ID);
				int docId = scoreDoc.doc;
				Document d = searcher.doc(docId);
				String title = d.get("title");  // this is the title field of the document
				hit0.setData(title);
				hit0.addToIndexes();
			}

			// after getting all hits, we can close the reader
			reader.close();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

	/**
	 * Any cleanup to be performed at the end of processing should go into this
	 * collectionProcessComplete() method (e.g., closing any open files/connections, etc.)
	 */
	@Override
	public void collectionProcessComplete() throws AnalysisEngineProcessException {
		super.collectionProcessComplete();
	}

}
