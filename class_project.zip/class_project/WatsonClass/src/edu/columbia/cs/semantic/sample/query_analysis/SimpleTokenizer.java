package edu.columbia.cs.semantic.sample.query_analysis;

import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;

import edu.columbia.cs.semantic.model.Token;

/**
 * This class implements a simple query analysis task of identifying tokens within the input query.
 * It simply uses whitespace to detect token boundaries. More sophisticated approaches may look into
 * multi-word tokens, lexical items from an ontology, etc.
 * 
 * @author Siddharth Patwardhan <sidd@patwardhans.net>
 */
public class SimpleTokenizer extends JCasAnnotator_ImplBase {

  /**
   * Any initializations of data structures/engines (e.g., dictionary) would go into the initialize
   * method. In this dummy class, we don't actually use an external resource.
   */
  @Override
  public void initialize(UimaContext aContext) throws ResourceInitializationException {
    super.initialize(aContext);
  }

  /**
   * Processes each CAS, and posts Token annotations over the tokens in the CAS
   */
  @Override
  public void process(JCas cas) throws AnalysisEngineProcessException {
    int state = 0;
    int begin = -1;
    for (int i = 0; i < cas.getDocumentText().length(); i++) {
      char cur = cas.getDocumentText().charAt(i);
      switch (state) {
        case 0:
          if (!isWhiteSpace(cur)) {
            begin = i;
            state = 1;
          }
          break;
        case 1:
          if (isWhiteSpace(cur)) {
            Token tok = new Token(cas, begin, i);
            tok.addToIndexes();
            state = 0;
          }
          break;
        default:
          throw new AnalysisEngineProcessException(new Throwable(
                  "Unexpected state in state machine"));
      }
    }
    if (state == 1) {
      Token tok = new Token(cas, begin, cas.getDocumentText().length());
      tok.addToIndexes();
    }
  }

  /**
   * Any cleanup to be performed at the end of processing should go into this
   * collectionProcessComplete() method (e.g., closing any open files/connections, etc.)
   */
  @Override
  public void collectionProcessComplete() throws AnalysisEngineProcessException {
    super.collectionProcessComplete();
  }

  /**
   * Tests if the input character is a whitespace character
   * 
   * @param cur
   *          the input character to test
   * @return true if cur is a whitespace, false otherwise
   */
  private boolean isWhiteSpace(char cur) {
    if (cur == ' ' || cur == '\t' || cur == '\n' || cur == '\r' || cur == '\f')
      return true;
    return false;
  }

}
