package edu.columbia.cs.semantic.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.flow.FinalStep;
import org.apache.uima.flow.Flow;
import org.apache.uima.flow.JCasFlow_ImplBase;
import org.apache.uima.flow.SimpleStep;
import org.apache.uima.flow.Step;
import org.apache.uima.jcas.JCas;

public class BaseQueryFlow extends JCasFlow_ImplBase {

  private static List<String> steps = new ArrayList<String>(Arrays.asList(
          "QueryAnalysisComponents", "PrimaryDocumentSearchComponents",
          "DocumentSearchCasMultiplier", "StructuredDataSearchComponents",
          "QueryExpansionComponents", "QueryExpansionCasMultiplier"));

  private int nextStep;

  public BaseQueryFlow() {
    super();
    nextStep = 0;
  }

  @Override
  public Step next() throws AnalysisEngineProcessException {
    if (nextStep >= steps.size())
      return new FinalStep();
    return new SimpleStep(steps.get(nextStep++));
  }

  @Override
  protected Flow newCasProduced(JCas newCas, String producedBy)
          throws AnalysisEngineProcessException {
    if ("DocumentSearchCasMultiplier".equals(producedBy))
      return new DocumentSearchFlow();
    if ("QueryExpansionCasMultiplier".equals(producedBy))
      return new QueryExpansionFlow();
    throw new AnalysisEngineProcessException(new Throwable(
            "Cannot compute flow for CAS from unknown source: " + producedBy));
  }

}
