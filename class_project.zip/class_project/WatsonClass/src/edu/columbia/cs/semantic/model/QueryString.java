

/* First created by JCasGen Wed Mar 06 00:08:02 EST 2013 */
package edu.columbia.cs.semantic.model;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;



/** Input query string annotation
 * Updated by JCasGen Wed Mar 06 00:08:02 EST 2013
 * XML source: /home/sid/Workspaces/ColumbiaProject/edu.columbia.cs.semantic.model/descriptors/edu/columbia/cs/semantic/model/types.xml
 * @generated */
public class QueryString extends SemanticSearchAnnotation {
  /** @generated
   * @ordered 
   */
  @SuppressWarnings ("hiding")
  public final static int typeIndexID = JCasRegistry.register(QueryString.class);
  /** @generated
   * @ordered 
   */
  @SuppressWarnings ("hiding")
  public final static int type = typeIndexID;
  /** @generated  */
  @Override
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected QueryString() {/* intentionally empty block */}
    
  /** Internal - constructor used by generator 
   * @generated */
  public QueryString(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public QueryString(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** @generated */  
  public QueryString(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }   

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {/*default - does nothing empty block */}
     
 
    
  //*--------------*
  //* Feature: queryId

  /** getter for queryId - gets ID of this query
   * @generated */
  public String getQueryId() {
    if (QueryString_Type.featOkTst && ((QueryString_Type)jcasType).casFeat_queryId == null)
      jcasType.jcas.throwFeatMissing("queryId", "edu.columbia.cs.semantic.model.QueryString");
    return jcasType.ll_cas.ll_getStringValue(addr, ((QueryString_Type)jcasType).casFeatCode_queryId);}
    
  /** setter for queryId - sets ID of this query 
   * @generated */
  public void setQueryId(String v) {
    if (QueryString_Type.featOkTst && ((QueryString_Type)jcasType).casFeat_queryId == null)
      jcasType.jcas.throwFeatMissing("queryId", "edu.columbia.cs.semantic.model.QueryString");
    jcasType.ll_cas.ll_setStringValue(addr, ((QueryString_Type)jcasType).casFeatCode_queryId, v);}    
  }

    