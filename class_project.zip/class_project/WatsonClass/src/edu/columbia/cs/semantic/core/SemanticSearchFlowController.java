package edu.columbia.cs.semantic.core;

import java.util.Map;

import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.analysis_engine.metadata.AnalysisEngineMetaData;
import org.apache.uima.flow.Flow;
import org.apache.uima.flow.FlowControllerContext;
import org.apache.uima.flow.JCasFlowController_ImplBase;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;

public class SemanticSearchFlowController extends JCasFlowController_ImplBase {

  @Override
  public void initialize(FlowControllerContext aContext) throws ResourceInitializationException {
    super.initialize(aContext);
    Map<String, AnalysisEngineMetaData> aeMap = aContext.getAnalysisEngineMetaDataMap();
    if (!aeMap.containsKey("QueryAnalysisComponents"))
      throw new ResourceInitializationException(
              new Throwable(
                      "Semantic Search Flow Controller requires QueryAnalysisComponents aggregate in the top-level descriptor"));
    if (!aeMap.containsKey("PrimaryDocumentSearchComponents"))
      throw new ResourceInitializationException(
              new Throwable(
                      "Semantic Search Flow Controller requires PrimaryDocumentSearchComponents aggregate in the top-level descriptor"));
    if (!aeMap.containsKey("StructuredDataSearchComponents"))
      throw new ResourceInitializationException(
              new Throwable(
                      "Semantic Search Flow Controller requires StructuredDataSearchComponents aggregate in the top-level descriptor"));
    if (!aeMap.containsKey("QueryExpansionComponents"))
      throw new ResourceInitializationException(
              new Throwable(
                      "Semantic Search Flow Controller requires QueryExpansionComponents aggregate in the top-level descriptor"));
    if (!aeMap.containsKey("SecondaryDocumentSearchComponents"))
      throw new ResourceInitializationException(
              new Throwable(
                      "Semantic Search Flow Controller requires SecondaryDocumentSearchComponents aggregate in the top-level descriptor"));
    if (!aeMap.containsKey("DocumentSearchCasMultiplier"))
      throw new ResourceInitializationException(
              new Throwable(
                      "Semantic Search Flow Controller requires DocumentSearchCasMultiplier in the top-level descriptor"));
    if (!aeMap.containsKey("QueryExpansionCasMultiplier"))
      throw new ResourceInitializationException(
              new Throwable(
                      "Semantic Search Flow Controller requires QueryExpansionCasMultiplier in the top-level descriptor"));
  }

  @Override
  public Flow computeFlow(JCas arg0) throws AnalysisEngineProcessException {
    return new BaseQueryFlow();
  }

}
