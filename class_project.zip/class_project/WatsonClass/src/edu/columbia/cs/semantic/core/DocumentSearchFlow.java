package edu.columbia.cs.semantic.core;

import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.flow.FinalStep;
import org.apache.uima.flow.JCasFlow_ImplBase;
import org.apache.uima.flow.Step;

public class DocumentSearchFlow extends JCasFlow_ImplBase {

  @Override
  public Step next() throws AnalysisEngineProcessException {
    return new FinalStep();
  }

}
