

/* First created by JCasGen Wed Mar 06 00:08:02 EST 2013 */
package edu.columbia.cs.semantic.model;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import org.apache.uima.jcas.cas.TOP;


/** Result from the lookup of a structured resource (e.g., entity/relation)
 * Updated by JCasGen Wed Mar 06 00:08:02 EST 2013
 * XML source: /home/sid/Workspaces/ColumbiaProject/edu.columbia.cs.semantic.model/descriptors/edu/columbia/cs/semantic/model/types.xml
 * @generated */
public class StructuredLookupResult extends TOP {
  /** @generated
   * @ordered 
   */
  @SuppressWarnings ("hiding")
  public final static int typeIndexID = JCasRegistry.register(StructuredLookupResult.class);
  /** @generated
   * @ordered 
   */
  @SuppressWarnings ("hiding")
  public final static int type = typeIndexID;
  /** @generated  */
  @Override
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected StructuredLookupResult() {/* intentionally empty block */}
    
  /** Internal - constructor used by generator 
   * @generated */
  public StructuredLookupResult(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public StructuredLookupResult(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {/*default - does nothing empty block */}
     
 
    
  //*--------------*
  //* Feature: data

  /** getter for data - gets The result of the structured lookup is stored in a free form string (allowing the flexibility of storing in various formats of data)
   * @generated */
  public String getData() {
    if (StructuredLookupResult_Type.featOkTst && ((StructuredLookupResult_Type)jcasType).casFeat_data == null)
      jcasType.jcas.throwFeatMissing("data", "edu.columbia.cs.semantic.model.StructuredLookupResult");
    return jcasType.ll_cas.ll_getStringValue(addr, ((StructuredLookupResult_Type)jcasType).casFeatCode_data);}
    
  /** setter for data - sets The result of the structured lookup is stored in a free form string (allowing the flexibility of storing in various formats of data) 
   * @generated */
  public void setData(String v) {
    if (StructuredLookupResult_Type.featOkTst && ((StructuredLookupResult_Type)jcasType).casFeat_data == null)
      jcasType.jcas.throwFeatMissing("data", "edu.columbia.cs.semantic.model.StructuredLookupResult");
    jcasType.ll_cas.ll_setStringValue(addr, ((StructuredLookupResult_Type)jcasType).casFeatCode_data, v);}    
   
    
  //*--------------*
  //* Feature: componentId

  /** getter for componentId - gets Component ID of the AE that performed the lookup
   * @generated */
  public String getComponentId() {
    if (StructuredLookupResult_Type.featOkTst && ((StructuredLookupResult_Type)jcasType).casFeat_componentId == null)
      jcasType.jcas.throwFeatMissing("componentId", "edu.columbia.cs.semantic.model.StructuredLookupResult");
    return jcasType.ll_cas.ll_getStringValue(addr, ((StructuredLookupResult_Type)jcasType).casFeatCode_componentId);}
    
  /** setter for componentId - sets Component ID of the AE that performed the lookup 
   * @generated */
  public void setComponentId(String v) {
    if (StructuredLookupResult_Type.featOkTst && ((StructuredLookupResult_Type)jcasType).casFeat_componentId == null)
      jcasType.jcas.throwFeatMissing("componentId", "edu.columbia.cs.semantic.model.StructuredLookupResult");
    jcasType.ll_cas.ll_setStringValue(addr, ((StructuredLookupResult_Type)jcasType).casFeatCode_componentId, v);}    
   
    
  //*--------------*
  //* Feature: score

  /** getter for score - gets A confidence score for this lookup result
   * @generated */
  public double getScore() {
    if (StructuredLookupResult_Type.featOkTst && ((StructuredLookupResult_Type)jcasType).casFeat_score == null)
      jcasType.jcas.throwFeatMissing("score", "edu.columbia.cs.semantic.model.StructuredLookupResult");
    return jcasType.ll_cas.ll_getDoubleValue(addr, ((StructuredLookupResult_Type)jcasType).casFeatCode_score);}
    
  /** setter for score - sets A confidence score for this lookup result 
   * @generated */
  public void setScore(double v) {
    if (StructuredLookupResult_Type.featOkTst && ((StructuredLookupResult_Type)jcasType).casFeat_score == null)
      jcasType.jcas.throwFeatMissing("score", "edu.columbia.cs.semantic.model.StructuredLookupResult");
    jcasType.ll_cas.ll_setDoubleValue(addr, ((StructuredLookupResult_Type)jcasType).casFeatCode_score, v);}    
  }

    