

/* First created by JCasGen Wed Mar 06 00:08:02 EST 2013 */
package edu.columbia.cs.semantic.model;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import org.apache.uima.jcas.cas.FSList;
import org.apache.uima.jcas.cas.TOP;


/** This UIMA object represents a list of SearchHit feature structures
 * Updated by JCasGen Wed Mar 06 00:08:02 EST 2013
 * XML source: /home/sid/Workspaces/ColumbiaProject/edu.columbia.cs.semantic.model/descriptors/edu/columbia/cs/semantic/model/types.xml
 * @generated */
public class SearchHitList extends TOP {
  /** @generated
   * @ordered 
   */
  @SuppressWarnings ("hiding")
  public final static int typeIndexID = JCasRegistry.register(SearchHitList.class);
  /** @generated
   * @ordered 
   */
  @SuppressWarnings ("hiding")
  public final static int type = typeIndexID;
  /** @generated  */
  @Override
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected SearchHitList() {/* intentionally empty block */}
    
  /** Internal - constructor used by generator 
   * @generated */
  public SearchHitList(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public SearchHitList(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {/*default - does nothing empty block */}
     
 
    
  //*--------------*
  //* Feature: list

  /** getter for list - gets The list of SearchHit feature structures
   * @generated */
  public FSList getList() {
    if (SearchHitList_Type.featOkTst && ((SearchHitList_Type)jcasType).casFeat_list == null)
      jcasType.jcas.throwFeatMissing("list", "edu.columbia.cs.semantic.model.SearchHitList");
    return (FSList)(jcasType.ll_cas.ll_getFSForRef(jcasType.ll_cas.ll_getRefValue(addr, ((SearchHitList_Type)jcasType).casFeatCode_list)));}
    
  /** setter for list - sets The list of SearchHit feature structures 
   * @generated */
  public void setList(FSList v) {
    if (SearchHitList_Type.featOkTst && ((SearchHitList_Type)jcasType).casFeat_list == null)
      jcasType.jcas.throwFeatMissing("list", "edu.columbia.cs.semantic.model.SearchHitList");
    jcasType.ll_cas.ll_setRefValue(addr, ((SearchHitList_Type)jcasType).casFeatCode_list, jcasType.ll_cas.ll_getFSRef(v));}    
  }

    