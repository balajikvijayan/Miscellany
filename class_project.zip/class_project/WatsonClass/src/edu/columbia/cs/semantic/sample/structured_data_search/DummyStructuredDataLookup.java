package edu.columbia.cs.semantic.sample.structured_data_search;

import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.CASException;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;

import edu.columbia.cs.semantic.model.StructuredLookupResult;
import edu.columbia.cs.semantic.utilities.UimaTools;

/**
 * This is a sample structured data lookup AE. It expects a CAS with a QUERY view, and uses the
 * contents of the QUERY view to perform a search over some structured resource. The output from
 * this AE is a bunch of StructuredLookupResult objects added to the QUERY view of the CAS.
 * 
 * @author Siddharth Patwardhan <sidd@patwardhans.net>
 */
public class DummyStructuredDataLookup extends JCasAnnotator_ImplBase {

  private static final String COMPONENT_ID = "DummyStructuredDataLookup";

  /**
   * Any initializations of data structures/engines (e.g., a retrieval engine) would go into the
   * initialize method. In this dummy class, we don't actually use a retrieval engine.
   */
  @Override
  public void initialize(UimaContext aContext) throws ResourceInitializationException {
    super.initialize(aContext);
  }

  /**
   * The process method receives one "query" CAS at a time, and performs a search for each.
   */
  @Override
  public void process(JCas cas) throws AnalysisEngineProcessException {
    JCas queryView;
    try {
      queryView = cas.getView("QUERY");
    } catch (CASException e) {
      throw new AnalysisEngineProcessException(e);
    }
    if (queryView == null)
      throw new AnalysisEngineProcessException(new Throwable(
              "Expecting QUERY view in CAS for primary document search"));
    try {
      if (UimaTools.casContainsView(cas, "EXPANDED"))
        throw new AnalysisEngineProcessException(
                new Throwable(
                        "Flow problem: found EXPANDED view in CAS; primary search CASes must not have EXPANDED view"));
    } catch (CASException e) {
      throw new AnalysisEngineProcessException(e);
    }

    // At this point we would perform a structured lookup using an external engine. However, in this
    // dummy class, we simply create a bunch of dummy structured lookup results.

    StructuredLookupResult hit0 = new StructuredLookupResult(queryView);
    hit0.setScore(0.9);
    hit0.setComponentId(COMPONENT_ID);
    hit0.setData("Tylenol treats headache");
    hit0.addToIndexes();

    StructuredLookupResult hit1 = new StructuredLookupResult(queryView);
    hit1.setScore(0.75);
    hit1.setComponentId(COMPONENT_ID);
    hit1.setData("headache indicates influenza");
    hit1.addToIndexes();

    StructuredLookupResult hit2 = new StructuredLookupResult(queryView);
    hit2.setScore(0.5);
    hit2.setComponentId(COMPONENT_ID);
    hit2.setData("influenza causedBy virus");
    hit2.addToIndexes();
  }

  /**
   * Any cleanup to be performed at the end of processing should go into this
   * collectionProcessComplete() method (e.g., closing any open files/connections, etc.)
   */
  @Override
  public void collectionProcessComplete() throws AnalysisEngineProcessException {
    super.collectionProcessComplete();
  }

}
