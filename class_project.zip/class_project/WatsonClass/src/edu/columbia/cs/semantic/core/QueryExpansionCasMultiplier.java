package edu.columbia.cs.semantic.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.uima.analysis_component.JCasMultiplier_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.cas.AbstractCas;
import org.apache.uima.cas.CAS;
import org.apache.uima.cas.CASException;
import org.apache.uima.examples.SourceDocumentInformation;
import org.apache.uima.jcas.JCas;
import org.apache.uima.util.CasCopier;

import edu.columbia.cs.semantic.model.DerivedQuery;
import edu.columbia.cs.semantic.utilities.UimaTools;
import edu.columbia.cs.semantic.utilities.UimaToolsException;

public class QueryExpansionCasMultiplier extends JCasMultiplier_ImplBase {

  private JCas baseCas;

  private List<DerivedQuery> queries;

  private String queryIdPrefix;

  private int nextIndex;

  @Override
  public boolean hasNext() throws AnalysisEngineProcessException {
    return nextIndex < queries.size();
  }

  @Override
  public AbstractCas next() throws AnalysisEngineProcessException {
    DerivedQuery nextHit = queries.get(nextIndex++);
    JCas newCas = getEmptyJCas();
    CasCopier copier = new CasCopier(baseCas.getCas(), newCas.getCas());
    try {
      if (UimaTools.casContainsView(baseCas, "QUERY"))
        copier.copyCasView(baseCas.getView("QUERY").getCas(), true);
      if (UimaTools.casContainsView(baseCas, "EXPANDED"))
        copier.copyCasView(baseCas.getView("EXPANDED").getCas(), true);
    } catch (CASException e) {
      throw new AnalysisEngineProcessException(e);
    }
    try {
      JCas initView = newCas.getView(CAS.NAME_DEFAULT_SOFA);
      SourceDocumentInformation sdi = UimaTools.getSingleton(initView,
              SourceDocumentInformation.type);
      if (sdi == null) {
        sdi = new SourceDocumentInformation(initView);
        sdi.addToIndexes();
      }
      sdi.setUri("file:/" + queryIdPrefix + "_derived_" + nextIndex);
      JCas docView = newCas.createView("EXPANDED");
      docView.setDocumentLanguage("en");
      docView.setDocumentText(nextHit.getQuery());
    } catch (CASException e) {
      throw new AnalysisEngineProcessException(e);
    } catch (UimaToolsException e) {
      throw new AnalysisEngineProcessException(e);
    }
    return newCas;
  }

  @Override
  public void process(JCas arg0) throws AnalysisEngineProcessException {
    baseCas = arg0;
    JCas queryView = null;
    try {
      queryView = arg0.getView("QUERY");
    } catch (CASException e) {
      throw new AnalysisEngineProcessException(e);
    }
    if (queryView == null)
      throw new AnalysisEngineProcessException(new Throwable("Expecting QUERY view in CAS"));
    try {
      JCas initView = arg0.getView(CAS.NAME_DEFAULT_SOFA);
      queryIdPrefix = ((SourceDocumentInformation) UimaTools.getSingleton(initView,
              SourceDocumentInformation.type)).getUri().replaceAll("^file:/", "");
      if (UimaTools.casContainsView(arg0, "EXPANDED"))
        throw new AnalysisEngineProcessException(
                new Throwable(
                        "Found EXPANDED view in CAS, not expecting at this stage (check your flow controller)"));
      Collection<DerivedQuery> queryCollection = UimaTools.getFSCollection(queryView,
              DerivedQuery.type);
      if (queryCollection != null)
        queries = new ArrayList<DerivedQuery>(queryCollection);
      else
        queries = new ArrayList<DerivedQuery>();
    } catch (CASException e) {
      throw new AnalysisEngineProcessException(e);
    } catch (UimaToolsException e) {
      throw new AnalysisEngineProcessException(e);
    }
    nextIndex = 0;
  }
}
