package edu.columbia.cs.semantic.core;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import org.apache.uima.UIMAFramework;
import org.apache.uima.analysis_engine.AnalysisEngine;
import org.apache.uima.analysis_engine.AnalysisEngineDescription;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.analysis_engine.CasIterator;
import org.apache.uima.cas.CAS;
import org.apache.uima.cas.CASException;
import org.apache.uima.collection.CasConsumer;
import org.apache.uima.collection.CasConsumerDescription;
import org.apache.uima.collection.CollectionException;
import org.apache.uima.collection.CollectionReader;
import org.apache.uima.collection.CollectionReaderDescription;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.resource.ResourceProcessException;
import org.apache.uima.util.InvalidXMLException;
import org.apache.uima.util.XMLInputSource;

import edu.columbia.cs.semantic.model.QueryString;
import edu.columbia.cs.semantic.utilities.UimaTools;
import edu.columbia.cs.semantic.utilities.UimaToolsException;

/**
 * This java class implements a "driver" program for the Semantic Search project. This driver
 * instantiates a UIMA pipeline with a specified UIMA descriptor, the input data and the directory
 * where the output is posted.
 * 
 * @author Siddharth Patwardhan <sidd@patwardhans.net>
 */
public class Driver {

  private static final String XMIWRITER_DESCRIPTOR_PATH = "/org/apache/uima/examples/xmi/XmiWriterCasConsumer.xml";

  /**
   * The main method of this Java class, runs the driver with the given input arguments.
   * 
   * @param args
   *          The given input arguments: args[0]=INPUTFILE, args[1]=OUTPUTDIR, args[2]=DESCRIPTOR
   */
  public static void main(String[] args) {

    // Validate the input arguments
    if (args.length == 0) {
      System.out.println("Usage: java " + Driver.class.getCanonicalName()
              + " INPUT OUTPUTDIR DESCRIPTOR");
      return;
    }
    if (args.length != 3) {
      System.err.println("Incorrect number of arguments");
      System.err.println("Usage: java " + Driver.class.getCanonicalName()
              + " INPUT OUTPUTDIR DESCRIPTOR");
      return;
    }

    // Initialize the collection reader
    System.err.println("Initializing collection reader");
    CollectionReader queryCollectionReader = null;
    try {
      CollectionReaderDescription queryReaderDescription = QueryCollectionReader.getDescription();
      queryReaderDescription.getMetaData().getConfigurationParameterSettings()
              .setParameterValue(QueryCollectionReader.PARAM_INPUT_FILE, args[0]);
      queryCollectionReader = UIMAFramework.produceCollectionReader(queryReaderDescription);
    } catch (InvalidXMLException e) {
      e.printStackTrace(System.err);
      return;
    } catch (ResourceInitializationException e) {
      e.printStackTrace(System.err);
      return;
    }

    // Initialize the analysis engine
    System.err.println("Initializing top-level analysis engine");
    AnalysisEngine topLevelEngine = null;
    URL descriptorURL = Driver.class.getResource(args[2]);
    if (descriptorURL == null) {
      System.err.println(args[2] + " not in classpath");
      return;
    }
    try {
      AnalysisEngineDescription topLevelDescriptor = UIMAFramework.getXMLParser()
              .parseAnalysisEngineDescription(new XMLInputSource(descriptorURL));
      topLevelEngine = UIMAFramework.produceAnalysisEngine(topLevelDescriptor);
    } catch (ResourceInitializationException e) {
      e.printStackTrace(System.err);
      return;
    } catch (InvalidXMLException e) {
      e.printStackTrace(System.err);
      return;
    } catch (IOException e) {
      e.printStackTrace(System.err);
      return;
    }

    // Initialize the XMI writer descriptor
    System.err.println("Initializing XmiWriterCasConsumer descriptor object");
    InputStream descriptorStream = Driver.class.getResourceAsStream(XMIWRITER_DESCRIPTOR_PATH);
    CasConsumerDescription xmiWriterDescriptor;
    try {
      xmiWriterDescriptor = UIMAFramework.getXMLParser().parseCasConsumerDescription(
              new XMLInputSource(descriptorStream, null));
    } catch (InvalidXMLException e) {
      e.printStackTrace(System.err);
      return;
    }

    // Iterate over the input queries, and apply the analysis engine to the
    // queries
    try {
      // Create a CAS from the top level descriptor
      CAS cas = topLevelEngine.newCAS();

      // Iterate over the input queries
      while (queryCollectionReader.hasNext()) {
        System.err.println("Processing query...");
        queryCollectionReader.getNext(cas);

        // Get the query ID for the output directory
        String queryId = null;
        JCas queryView = cas.getJCas().getView("QUERY");
        QueryString qString = UimaTools.getSingleton(queryView, QueryString.type);
        queryId = qString.getQueryId();
        System.err.println("... query ID " + queryId);
        File outputDirectory = new File(args[1], queryId);
        if (!outputDirectory.exists()) {
          if (!outputDirectory.mkdir()) {
            System.err.println("Unable to create output directory: "
                    + outputDirectory.getAbsolutePath());
            return;
          }
        }
        System.err.println("Output CASes for this query in: " + outputDirectory.getAbsolutePath());

        // Create an XMI writer for the specified output directory
        xmiWriterDescriptor.getMetaData().getConfigurationParameterSettings()
                .setParameterValue("OutputDirectory", outputDirectory.getAbsolutePath());
        CasConsumer xmiWriterCasConsumer = UIMAFramework.produceCasConsumer(xmiWriterDescriptor);

        // Write out the base CAS from the top-level analysis engine
        xmiWriterCasConsumer.processCas(cas);
        printOutput(cas);

        // Apply top-level analysis engine to the query
        CasIterator outputCASesIterator = topLevelEngine.processAndOutputNewCASes(cas);

        // Write out the CASes generated by the top-level analysis
        // engine
        while (outputCASesIterator.hasNext()) {
          CAS nextCAS = outputCASesIterator.next();
          xmiWriterCasConsumer.processCas(nextCAS);
          printOutput(nextCAS);
          nextCAS.release();
        }

        // Reset the CAS
        cas.reset();
      }

      // Call collectionProcessComplete() on the top-level analysis engine
      topLevelEngine.collectionProcessComplete();

    } catch (AnalysisEngineProcessException e) {
      e.printStackTrace(System.err);
      return;
    } catch (CollectionException e) {
      e.printStackTrace(System.err);
      return;
    } catch (IOException e) {
      e.printStackTrace(System.err);
      return;
    } catch (ResourceInitializationException e) {
      e.printStackTrace(System.err);
      return;
    } catch (CASException e) {
      e.printStackTrace(System.err);
      return;
    } catch (UimaToolsException e) {
      e.printStackTrace(System.err);
      return;
    } catch (ResourceProcessException e) {
      e.printStackTrace(System.err);
      return;
    }
  }

  private static void printOutput(CAS cas) {
    CAS document = null;
    if (UimaTools.casContainsView(cas, "DOCUMENT"))
      document = cas.getView("DOCUMENT");
    CAS expanded = null;
    if (UimaTools.casContainsView(cas, "EXPANDED"))
      expanded = cas.getView("EXPANDED");
    CAS query = cas.getView("QUERY");
    if (document != null) {
      String queryString = query.getDocumentText();
      if (expanded != null)
        queryString = expanded.getDocumentText();
      System.err.println("For " + ((expanded != null) ? "expanded" : "base") + " query: "
              + queryString);
      System.err.println("Document retrieved: "
              + document.getDocumentText()
                      .substring(0, Math.min(document.getDocumentText().length(), 100))
                      .replaceAll("[\\r\\f\\n]+", " ") + "... ");
    } else if (expanded != null) {
      System.err.println("Expanded QUERY: " + expanded.getDocumentText());
    } else {
      System.err.println("Base QUERY: " + query.getDocumentText());
    }
  }

}
