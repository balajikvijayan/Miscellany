package edu.columbia.cs.semantic.utilities;

public class Pair<T1, T2> {

  private T1 firstElement;

  private T2 secondElement;

  public Pair(T1 first, T2 second) {
    this.firstElement = first;
    this.secondElement = second;
  }

  public T1 getFirstElement() {
    return firstElement;
  }

  public T2 getSecondElement() {
    return secondElement;
  }

}
