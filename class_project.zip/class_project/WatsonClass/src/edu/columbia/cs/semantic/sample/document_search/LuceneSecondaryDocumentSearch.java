package edu.columbia.cs.semantic.sample.document_search;

import java.io.File;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.apache.uima.UimaContext;
import org.apache.uima.analysis_component.JCasAnnotator_ImplBase;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.cas.EmptyFSList;
import org.apache.uima.jcas.cas.FSList;
import org.apache.uima.resource.ResourceInitializationException;

import edu.columbia.cs.semantic.env.Env;
import edu.columbia.cs.semantic.model.SearchHit;
import edu.columbia.cs.semantic.model.SearchHitList;
import edu.columbia.cs.semantic.utilities.UimaTools;
import edu.columbia.cs.semantic.utilities.UimaToolsException;

/**
 * This is the Lucene secondary document search AE. It expects a CAS with a EXPANDED view, and uses
 * the contents of this view to perform a document search. The output from this AE is a
 * SearchHitList added to the EXPANDED view of the CAS.
 *
 * @author Or Biran
 */
public class LuceneSecondaryDocumentSearch extends JCasAnnotator_ImplBase {

	private static final String COMPONENT_ID = "LuceneSecondaryDocumentSearch";

	/**
	 * Any initializations of data structures/engines (e.g., a retrieval engine) would go into the
	 * initialize method. In this dummy class, we don't actually use a retrieval engine.
	 */
	@Override
	public void initialize(UimaContext aContext) throws ResourceInitializationException {
		super.initialize(aContext);
	}

	/**
	 * The process method receives one "query" CAS at a time, and performs a document search for each.
	 */
	@Override
	public void process(JCas cas) throws AnalysisEngineProcessException {
		JCas queryView;
		SearchHitList hits;
		try {
			queryView = cas.getView("EXPANDED");
			if (queryView == null) throw new Exception("Expecting EXPANDED view in CAS for primary document search");

			hits = UimaTools.getSingleton(queryView, SearchHitList.type);
			if (hits == null) {
				hits = new SearchHitList(queryView);
				hits.setList(new EmptyFSList(queryView));
				hits.addToIndexes();
			}
		} catch (Exception e) {
			throw new AnalysisEngineProcessException(e);
		}

		try {
			// prepare the lucene index and analyzer
			String indexDir = Env.getIndexDir();
			Directory index = FSDirectory.open(new File(indexDir));
			StandardAnalyzer analyzer = new StandardAnalyzer(Version.LUCENE_41);

			// the query comes from the queryView 
			Query query = new QueryParser(Version.LUCENE_41, "text", analyzer).parse(queryView.getDocumentText());

			// get the top 10 hits
			IndexReader reader = DirectoryReader.open(index);
			IndexSearcher searcher = new IndexSearcher(reader);
			TopScoreDocCollector collector = TopScoreDocCollector.create(/*numHits*/ 10, /*ordered*/ true);
			searcher.search(query, collector);
			ScoreDoc[] scoreDocs = collector.topDocs().scoreDocs;

			// insert to uima hits object
			int c = 0;
			for (ScoreDoc scoreDoc : scoreDocs) {
				SearchHit hit = new SearchHit(queryView);
				hit.setRank(++c);
				hit.setScore(scoreDoc.score);
				hit.setComponentId(COMPONENT_ID);
				int docId = scoreDoc.doc;
				Document d = searcher.doc(docId);
				String text = d.get("text");  // this is the text field of the document
				hit.setText(text);
				FSList expandedList;
				try {
					expandedList = UimaTools.addToFSList(hits.getList(), hit);
				} catch (UimaToolsException e) {
					throw new AnalysisEngineProcessException(e);
				}
				hits.setList(expandedList);
			}

			// after getting all hits, we can close the reader
			reader.close();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Any cleanup to be performed at the end of processing should go into this
	 * collectionProcessComplete() method (e.g., closing any open files/connections, etc.)
	 */
	@Override
	public void collectionProcessComplete() throws AnalysisEngineProcessException {
		super.collectionProcessComplete();
	}

}
