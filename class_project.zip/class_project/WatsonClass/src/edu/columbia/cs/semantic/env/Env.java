package edu.columbia.cs.semantic.env;

import java.io.FileReader;
import java.util.Properties;

/**
 * @author Or
 *
 */
public class Env {

	private static final String PROPERTIES_FILE = "config/properties";
	
	private static Properties _properties;
	
	public static String getIndexDir() {
		return getProperty("indexDir");
	}

	private static String getProperty(String name) {
		if (_properties == null) _properties = loadProperties();
		if (_properties.get(name) == null) throw new RuntimeException("Could not find property: " + name);
		return _properties.getProperty(name);
	}

	private static Properties loadProperties() {
		Properties props = new Properties();
		
		try {
			
			FileReader reader = new FileReader(PROPERTIES_FILE);
			props.load(reader);
			return props;

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
