

/* First created by JCasGen Wed Mar 06 00:08:02 EST 2013 */
package edu.columbia.cs.semantic.model;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import org.apache.uima.jcas.tcas.Annotation;


/** Top-level class representing an annotation in this project
 * Updated by JCasGen Wed Mar 06 00:08:02 EST 2013
 * XML source: /home/sid/Workspaces/ColumbiaProject/edu.columbia.cs.semantic.model/descriptors/edu/columbia/cs/semantic/model/types.xml
 * @generated */
public class SemanticSearchAnnotation extends Annotation {
  /** @generated
   * @ordered 
   */
  @SuppressWarnings ("hiding")
  public final static int typeIndexID = JCasRegistry.register(SemanticSearchAnnotation.class);
  /** @generated
   * @ordered 
   */
  @SuppressWarnings ("hiding")
  public final static int type = typeIndexID;
  /** @generated  */
  @Override
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected SemanticSearchAnnotation() {/* intentionally empty block */}
    
  /** Internal - constructor used by generator 
   * @generated */
  public SemanticSearchAnnotation(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public SemanticSearchAnnotation(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** @generated */  
  public SemanticSearchAnnotation(JCas jcas, int begin, int end) {
    super(jcas);
    setBegin(begin);
    setEnd(end);
    readObject();
  }   

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {/*default - does nothing empty block */}
     
 
    
  //*--------------*
  //* Feature: componentId

  /** getter for componentId - gets ID of the component that posted this annotation
   * @generated */
  public String getComponentId() {
    if (SemanticSearchAnnotation_Type.featOkTst && ((SemanticSearchAnnotation_Type)jcasType).casFeat_componentId == null)
      jcasType.jcas.throwFeatMissing("componentId", "edu.columbia.cs.semantic.model.SemanticSearchAnnotation");
    return jcasType.ll_cas.ll_getStringValue(addr, ((SemanticSearchAnnotation_Type)jcasType).casFeatCode_componentId);}
    
  /** setter for componentId - sets ID of the component that posted this annotation 
   * @generated */
  public void setComponentId(String v) {
    if (SemanticSearchAnnotation_Type.featOkTst && ((SemanticSearchAnnotation_Type)jcasType).casFeat_componentId == null)
      jcasType.jcas.throwFeatMissing("componentId", "edu.columbia.cs.semantic.model.SemanticSearchAnnotation");
    jcasType.ll_cas.ll_setStringValue(addr, ((SemanticSearchAnnotation_Type)jcasType).casFeatCode_componentId, v);}    
   
    
  //*--------------*
  //* Feature: confidence

  /** getter for confidence - gets Confidence associated with this annotation
   * @generated */
  public double getConfidence() {
    if (SemanticSearchAnnotation_Type.featOkTst && ((SemanticSearchAnnotation_Type)jcasType).casFeat_confidence == null)
      jcasType.jcas.throwFeatMissing("confidence", "edu.columbia.cs.semantic.model.SemanticSearchAnnotation");
    return jcasType.ll_cas.ll_getDoubleValue(addr, ((SemanticSearchAnnotation_Type)jcasType).casFeatCode_confidence);}
    
  /** setter for confidence - sets Confidence associated with this annotation 
   * @generated */
  public void setConfidence(double v) {
    if (SemanticSearchAnnotation_Type.featOkTst && ((SemanticSearchAnnotation_Type)jcasType).casFeat_confidence == null)
      jcasType.jcas.throwFeatMissing("confidence", "edu.columbia.cs.semantic.model.SemanticSearchAnnotation");
    jcasType.ll_cas.ll_setDoubleValue(addr, ((SemanticSearchAnnotation_Type)jcasType).casFeatCode_confidence, v);}    
  }

    