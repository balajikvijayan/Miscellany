

/* First created by JCasGen Wed Mar 06 00:08:02 EST 2013 */
package edu.columbia.cs.semantic.model;

import org.apache.uima.jcas.JCas; 
import org.apache.uima.jcas.JCasRegistry;
import org.apache.uima.jcas.cas.TOP_Type;

import org.apache.uima.jcas.cas.TOP;


/** A search query dervied from the base query, by query expansion or other means
 * Updated by JCasGen Wed Mar 06 00:08:02 EST 2013
 * XML source: /home/sid/Workspaces/ColumbiaProject/edu.columbia.cs.semantic.model/descriptors/edu/columbia/cs/semantic/model/types.xml
 * @generated */
public class DerivedQuery extends TOP {
  /** @generated
   * @ordered 
   */
  @SuppressWarnings ("hiding")
  public final static int typeIndexID = JCasRegistry.register(DerivedQuery.class);
  /** @generated
   * @ordered 
   */
  @SuppressWarnings ("hiding")
  public final static int type = typeIndexID;
  /** @generated  */
  @Override
  public              int getTypeIndexID() {return typeIndexID;}
 
  /** Never called.  Disable default constructor
   * @generated */
  protected DerivedQuery() {/* intentionally empty block */}
    
  /** Internal - constructor used by generator 
   * @generated */
  public DerivedQuery(int addr, TOP_Type type) {
    super(addr, type);
    readObject();
  }
  
  /** @generated */
  public DerivedQuery(JCas jcas) {
    super(jcas);
    readObject();   
  } 

  /** <!-- begin-user-doc -->
    * Write your own initialization here
    * <!-- end-user-doc -->
  @generated modifiable */
  private void readObject() {/*default - does nothing empty block */}
     
 
    
  //*--------------*
  //* Feature: query

  /** getter for query - gets The text of the expanded query
   * @generated */
  public String getQuery() {
    if (DerivedQuery_Type.featOkTst && ((DerivedQuery_Type)jcasType).casFeat_query == null)
      jcasType.jcas.throwFeatMissing("query", "edu.columbia.cs.semantic.model.DerivedQuery");
    return jcasType.ll_cas.ll_getStringValue(addr, ((DerivedQuery_Type)jcasType).casFeatCode_query);}
    
  /** setter for query - sets The text of the expanded query 
   * @generated */
  public void setQuery(String v) {
    if (DerivedQuery_Type.featOkTst && ((DerivedQuery_Type)jcasType).casFeat_query == null)
      jcasType.jcas.throwFeatMissing("query", "edu.columbia.cs.semantic.model.DerivedQuery");
    jcasType.ll_cas.ll_setStringValue(addr, ((DerivedQuery_Type)jcasType).casFeatCode_query, v);}    
   
    
  //*--------------*
  //* Feature: componentId

  /** getter for componentId - gets Component ID of the AE that posted this derived query
   * @generated */
  public String getComponentId() {
    if (DerivedQuery_Type.featOkTst && ((DerivedQuery_Type)jcasType).casFeat_componentId == null)
      jcasType.jcas.throwFeatMissing("componentId", "edu.columbia.cs.semantic.model.DerivedQuery");
    return jcasType.ll_cas.ll_getStringValue(addr, ((DerivedQuery_Type)jcasType).casFeatCode_componentId);}
    
  /** setter for componentId - sets Component ID of the AE that posted this derived query 
   * @generated */
  public void setComponentId(String v) {
    if (DerivedQuery_Type.featOkTst && ((DerivedQuery_Type)jcasType).casFeat_componentId == null)
      jcasType.jcas.throwFeatMissing("componentId", "edu.columbia.cs.semantic.model.DerivedQuery");
    jcasType.ll_cas.ll_setStringValue(addr, ((DerivedQuery_Type)jcasType).casFeatCode_componentId, v);}    
   
    
  //*--------------*
  //* Feature: score

  /** getter for score - gets Confidence of the AE in the derived query
   * @generated */
  public double getScore() {
    if (DerivedQuery_Type.featOkTst && ((DerivedQuery_Type)jcasType).casFeat_score == null)
      jcasType.jcas.throwFeatMissing("score", "edu.columbia.cs.semantic.model.DerivedQuery");
    return jcasType.ll_cas.ll_getDoubleValue(addr, ((DerivedQuery_Type)jcasType).casFeatCode_score);}
    
  /** setter for score - sets Confidence of the AE in the derived query 
   * @generated */
  public void setScore(double v) {
    if (DerivedQuery_Type.featOkTst && ((DerivedQuery_Type)jcasType).casFeat_score == null)
      jcasType.jcas.throwFeatMissing("score", "edu.columbia.cs.semantic.model.DerivedQuery");
    jcasType.ll_cas.ll_setDoubleValue(addr, ((DerivedQuery_Type)jcasType).casFeatCode_score, v);}    
  }

    